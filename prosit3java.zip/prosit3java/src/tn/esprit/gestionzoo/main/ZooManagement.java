public class Zoomanagement {

        public static void main(String[] args) {
                Animal lion = new Animal();
                lion.name = "Simba";
                lion.age = 8;
                lion.family = "Cats";
                lion.isMammal = true;

                Zoo myZoo = new Zoo(" wPark", "Ariana");
                Zoo notMyZoo = new Zoo("lcjfk", "gafsa");


                Animal dog = new Animal("Cfdoiugd", "Sfvjy", 4, true);


                System.out.println(myZoo.addAnimal(lion));
                System.out.println(myZoo.addAnimal(dog));
                System.out.println(myZoo.addAnimal(dog));

                myZoo.displayAnimals();

                System.out.println(myZoo.searchAnimal(dog));
                Animal dog2 = new Animal("dfnfffe", "dsk", 4, true);
                System.out.println(myZoo.searchAnimal(dog));

                //   System.out.println(myZoo.removeAnimal(dog));
                myZoo.displayAnimals();


                System.out.println(myZoo);

                myZoo.addAnimal(lion);
                myZoo.addAnimal(dog);
                myZoo.addAnimal(dog2);
                myZoo.displayAnimals();
                System.out.println("a" + myZoo.removeAnimal(lion));
                myZoo.displayAnimals();
                System.out.println("a" + myZoo.removeAnimal(dog2));
                myZoo.displayAnimals();
                System.out.println("a" + myZoo.removeAnimal(dog));
                myZoo.displayAnimals();

//        System.out.println(Zoo.comparerZoo(myZoo, notMyZoo));
//        System.out.println(myZoo.isZooFull());

        }

}